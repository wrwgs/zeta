# ZETA behavioural baselines

Recorded from the ZETA 1.5 reference implementation (the prebuilt `classes.jar` of the 2002
binary distribution) by `harness/baseline.py`. These are the regression oracle for the
Pizza→Java port: run the same corpus against a ported build and compare.

    ../harness/baseline.py --check                    # against the reference
    ../harness/baseline.py --check --classes <DIR>    # against another build

Layout: `<example>/<unit>.<content-type>` plus `<example>/session.transcript`.
`_at_` stands for `#` in unit names (`BBSpec_at_bbook` = `LTX:BBSpec#bbook`).

`EXCLUDED` lists artifacts that are not reproducible between two runs of the reference itself,
so they cannot serve as baselines. Every one traces to `Name.hashCode()`/`compareTo()` being
identity-hash based (`src/util/Name.pizza`), which makes `Set<Name>` iteration order depend on
JVM address layout. See `../zesurrect-plan.md` §7.3.

Do not hand-edit these files; regenerate with `--update`, which records a value only when two
independent runs agree.
