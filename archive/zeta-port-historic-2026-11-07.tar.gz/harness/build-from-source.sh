#!/bin/sh
# Reproduce the ZETA 1.5 from-source build, as far as it currently goes.
#
# State (see zesurrect-plan.md §3): everything here is reproducible and clean up to the final
# step.  Pizza 1.1's FRONT END accepts all 186 sources with zero errors, and its Pizza->Java
# TRANSLATION emits 262 .java files with zero errors.  Pizza's back-end type checker is broken
# on this codebase -- it reports ~100 errors, each one preceded by Pizza's own
# "Suspicious error message -- there might be something wrong with the Pizza->Java translation"
# banner.  So this script stops with a translated Java tree, not class files.
#
#   ./build-from-source.sh [workdir]        default workdir: ../work/build-src
#
# Prerequisites, all under recovered/tools/: jdk8, pizza-1.1.jar, jdk6-rt/, javacc/javacc-3.2.jar

set -e

HERE=$(cd "$(dirname "$0")" && pwd)
ZETA=$(cd "$HERE/.." && pwd)
T=$ZETA/recovered/tools
SRC=$ZETA/recovered/src/zeta-1.5
B=${1:-$ZETA/work/build-src}

JAVA=$T/jdk8/bin/java
PIZZA="$T/pizza-1.1.jar"
BOOTCP="$T/jdk6-rt/rt.jar:$T/jdk6-rt/jce.jar:$T/jdk6-rt/jsse.jar"

echo "==> staging a pristine copy in $B/zeta"
mkdir -p "$B"
rm -rf "$B/zeta" 2>/dev/null || true
cp -r "$SRC" "$B/zeta"
find "$B/zeta" -name '.etstate.java' -delete

echo "==> collecting the official source list (ETMakefile PIZZA_FILES / JAVA_FILES)"
( cd "$B/zeta" && python3 "$HERE/collect_sources.py" src ) | sed 's|^|src/|' \
    | LC_ALL=C sort -u > "$B/sources_mk.txt"
echo "    $(wc -l < "$B/sources_mk.txt") units"

echo "==> applying the Java-5 source fixes (Pizza 1.1 cannot model covariant returns)"
python3 "$HERE/apply_pizza_java5_fixes.py" --sources "$B/zeta/src" | tail -1

echo "==> regenerating the three grammars with JavaCC 3.2"
for pair in "src/meta/genlexis Parser.jj" \
            "src/tools/latex LatexScanner.jj" \
            "src/tools/zparser ItemParser.jj"; do
    d=$(echo "$pair" | cut -d' ' -f1)
    g=$(echo "$pair" | cut -d' ' -f2)
    ( cd "$B/zeta/$d" && "$JAVA" -cp "$T/javacc/javacc-3.2.jar" \
        org.javacc.parser.Main "$g" >/dev/null )
    echo "    $d/$g"
done

echo "==> applying the Java-5 fixes to JavaCC's stock templates"
python3 "$HERE/apply_pizza_java5_fixes.py" --generated "$B/zeta/src" | tail -1

echo "==> assembling the full source list"
( cd "$B/zeta" && {
    cat "$B/sources_mk.txt"
    for d in src/meta/genlexis src/tools/latex src/tools/zparser; do
        ls $d/*.java 2>/dev/null
    done
  } | grep -v 'ASCII_UCodeESC_CharStream.java' | LC_ALL=C sort -u > "$B/sources_full.txt" )
echo "    $(wc -l < "$B/sources_full.txt") units"

# NOTE: neither the output directory nor classes.jar may appear on Pizza's classpath.  A
# whole-program compile needs no prior classes, and mixing stale ones in yields bogus errors.
echo "==> Pizza front end + Pizza->Java translation (-s)"
rm -rf "$B/javasrc" 2>/dev/null || true
mkdir -p "$B/javasrc"
( cd "$B/zeta" && "$JAVA" -Xmx2g -cp "$PIZZA" net.sf.pizzacompiler.compiler.Main \
    -nowarn -s -bootclasspath "$BOOTCP" -classpath "$PIZZA" \
    -d "$B/javasrc" $(cat "$B/sources_full.txt") ) > "$B/translate.log" 2>&1 || true
errs=$(grep -cE '^src/.*:[0-9]+:' "$B/translate.log" || true)
echo "    translation errors: $errs   java files: $(find "$B/javasrc" -name '*.java' | wc -l)"
[ "$errs" = "0" ] || { echo "    !! expected 0; see $B/translate.log"; exit 1; }

echo "==> repairing Pizza's emitter output (brace-less try bodies)"
python3 "$HERE/fix_pizza_emitted_java.py" "$B/javasrc" | tail -1

cat <<EOF

Done, as far as the route goes.

  translated Java : $B/javasrc
  logs            : $B/translate.log

To see the remaining gap, compile it (expect ~296 semantic errors, all from the emitter writing
binary names such as ZAM\$CodeFormatter where ZAM.CodeFormatter is required -- plan §3.3):

  $T/jdk8/bin/javac -nowarn -source 1.4 -target 1.4 -encoding latin1 \\
      -cp $PIZZA -d $B/classes \$(find $B/javasrc -name '*.java')

For a working ZETA today, use the prebuilt reference instead (plan §2):  run/zeta -b
EOF
