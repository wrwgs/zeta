#!/usr/bin/env python3
"""Report the `$$tag` value of every case of a Pizza algebraic data type.

Tag values are part of the ABI.  Compiled consumers dispatch with `getfield $$tag` followed by
a `lookupswitch`, so a case that is given the wrong number in the port does not fail to link --
it silently takes another case's branch.  With 2,040 case declarations to port, reading the
numbers out of the class files beats inferring them from declaration order, which is only a
convention and is easy to get wrong where nested ADTs are interleaved with the cases of their
enclosing type (`zeta.content.text.Text` does exactly that).

Two shapes have to be read, because Pizza compiles a nullary case two different ways
(zesurrect-plan.md 9.6):

  * a case WITH parameters, or with empty parentheses, is a subclass whose constructor calls
    `super(N)` -- the tag is the constant pushed before that `invokespecial`;
  * a case WITHOUT parentheses is a `public static final` constant on the base, built in the
    base's `<clinit>` by `new <base>(N)`.

    adt_tags.py zeta.content.text.Text [more classes ...]
    adt_tags.py --all                         # every ADT base in the reference jar
"""
import argparse
import os
import re
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ZETA = os.path.dirname(HERE)
JAVAP = os.path.join(ZETA, "recovered/tools/jdk21/bin/javap")
REFERENCE = os.path.join(ZETA, "work/ref-classes")

PUSH = re.compile(r"\b(?:iconst_(\d)|bipush\s+(-?\d+)|sipush\s+(-?\d+)|ldc\s+#\d+\s*//\s*int (-?\d+))")


def javap(classpath, cls, *flags):
    out = subprocess.run([JAVAP, *flags, "-classpath", classpath, cls],
                         capture_output=True, text=True)
    return out.stdout if out.returncode == 0 else None


def _pushed_before(lines, i):
    """The int constant pushed most recently before line i."""
    for line in reversed(lines[:i]):
        m = PUSH.search(line)
        if m:
            return int(next(g for g in m.groups() if g is not None))
    return None


def case_tags(classpath, base):
    """{case name: tag} for the subclasses and the constants of `base`."""
    simple = base.rsplit(".", 1)[1]
    internal = base.replace(".", "/")
    tags = {}

    # subclass cases: their <init> calls super(N)
    tree = os.path.join(classpath, *base.split("."))
    directory = os.path.dirname(tree)
    prefix = os.path.basename(tree) + "$"
    if os.path.isdir(directory):
        for f in sorted(os.listdir(directory)):
            if not (f.startswith(prefix) and f.endswith(".class")):
                continue
            sub = f[:-len(".class")]
            if "$" in sub[len(prefix):]:        # a nested type of a case, not a case
                continue
            text = javap(classpath, base.rsplit(".", 1)[0] + "." + sub, "-p", "-c")
            if text is None:
                continue
            lines = text.split("\n")
            for i, line in enumerate(lines):
                if 'invokespecial' in line and internal + '."<init>":(I)V' in line:
                    tags[sub[len(prefix):]] = _pushed_before(lines, i)
                    break

    # Constant cases: built in the base's <clinit> by `new <base>(N)` then putstatic'd.
    #
    # Note the match here does NOT require the owner: inside a class's own code javap prints a
    # self-reference as `Method "<init>":(I)V`, with no class name, which is why an earlier
    # version of this found every subclass case and none of the constants.
    text = javap(classpath, base, "-p", "-c")
    if text:
        lines = text.split("\n")
        pending = None
        for i, line in enumerate(lines):
            if 'invokespecial' in line and '"<init>":(I)V' in line:
                pending = _pushed_before(lines, i)
            elif "putstatic" in line and pending is not None:
                # The field's type must BE the ADT base: a class's <clinit> also stores
                # ordinary statics, and `MZ$Expr.renameCounter` (an int) was being reported
                # as a case with tag 0 until this check was added.  A phantom case is not
                # harmless -- --check compares two sets, and a spurious entry on one side is
                # exactly what would mask a real difference.
                m = re.search(r"//\s*Field (\w+):(\S+)", line)
                if m and m.group(2) == "L" + internal + ";":
                    tags[m.group(1)] = pending
                pending = None
    return tags


def adt_bases(classpath):
    """Classes that declare a `$$tag` field: the ADT bases."""
    found = []
    for dirpath, _d, files in os.walk(classpath):
        for f in files:
            if not f.endswith(".class"):
                continue
            rel = os.path.relpath(os.path.join(dirpath, f), classpath)
            cls = rel[: -len(".class")].replace(os.sep, ".")
            if not cls.startswith("zeta.") or "$$" in cls:
                continue
            text = javap(classpath, cls, "-p")
            # the field name is the mangled `zeta$pkg$Class$$tag`, so `$` must be in the
            # character class -- `\w` alone matches nothing here
            if text and re.search(r"int [\w$]+\$\$tag;", text):
                found.append(cls)
    return sorted(found)


def check(ported, reference):
    """Compare the tags of every ADT the port has replaced with the reference's.

    This is the one ABI property that neither the gate nor the oracle can see. `abi_gate.py`
    resolves members, and a tag is a *value*, not a member; the oracle only notices if a
    specification happens to exercise the mis-tagged branch. A wrong tag therefore sends a
    compiled `lookupswitch` down another case's arm, silently.
    """
    bases = [c for c in adt_bases(ported) if javap(reference, c, "-p") is not None]
    bad, notes = 0, []
    for base in bases:
        ref = case_tags(reference, base)
        new = case_tags(ported, base)
        changed = {k: (v, new[k]) for k, v in ref.items() if k in new and new[k] != v}
        # A case the port does not declare is only a problem if the port also shadows its
        # class, because otherwise the 2002 case class is still on the classpath and still
        # extends the ported base.  `zeta.session.Locator$VisitCapability` is the live
        # example: the jar has both `FileVisit` and `TextVisit` -- the archived source is a
        # later revision in which the case was renamed -- and `zeta.tools.sh.FileVisitor`
        # still uses the older one.  Dropping it from the port is right; the binary class
        # keeps working, and `abi_gate.py` is what proves that it resolves.
        inherited = [k for k in ref if k not in new
                     and os.path.exists(os.path.join(
                         ported, *(base + "$" + k).split("."))) is False]
        dropped = [k for k in ref if k not in new and k not in inherited]
        added = {k: v for k, v in new.items() if k not in ref}
        if changed or dropped:
            bad += 1
            print("FAIL %s" % base)
            for k in sorted(dropped):
                print("     case %s (tag %s) is gone and the port shadows its class"
                      % (k, ref[k]))
            for k, (was, now) in sorted(changed.items()):
                print("     case %s: tag %s -> %s" % (k, was, now))
        else:
            print("ok   %-54s %d case(s)%s"
                  % (base, len(new), "  (+%d added)" % len(added) if added else ""))
        for k in sorted(inherited):
            notes.append("%s.%s (tag %s) left to the 2002 class file" % (base, k, ref[k]))
        dup = {}
        for k, v in ref.items():
            dup.setdefault(v, []).append(k)
        for v, ks in sorted(dup.items()):
            if len(ks) > 1:
                notes.append("%s: tag %s is shared by %s -- two revisions in one jar"
                             % (base, v, " and ".join(sorted(ks))))
    if notes:
        print("\nnotes:")
        for n in notes:
            print("    %s" % n)
    print("\n%d ADT(s) checked, %d with a tag or case difference" % (len(bases), bad))
    return 1 if bad else 0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("classes", nargs="*")
    ap.add_argument("--all", action="store_true", help="every ADT base in the reference jar")
    ap.add_argument("--classpath", default=REFERENCE)
    ap.add_argument("--check", action="store_true",
                    help="compare every ADT the port has replaced against the reference, and "
                         "report any case whose tag, or whose presence, differs")
    ap.add_argument("--ported", default=os.path.join(ZETA, "port/classes"))
    args = ap.parse_args()

    if args.check:
        return check(args.ported, args.classpath)

    targets = args.classes
    if args.all:
        targets = adt_bases(args.classpath)
    if not targets:
        ap.error("name at least one class, or pass --all")

    total = 0
    for base in targets:
        tags = case_tags(args.classpath, base)
        if not tags:
            continue
        print("%s" % base)
        for name, tag in sorted(tags.items(), key=lambda kv: (kv[1] is None, kv[1], kv[0])):
            print("    %-3s %s" % (tag if tag is not None else "?", name))
        total += len(tags)
    print("\n%d case(s) in %d ADT(s)" % (total, len(targets)))
    return 0


if __name__ == "__main__":
    sys.exit(main())
