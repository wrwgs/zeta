#!/usr/bin/env python3
"""Report which Pizza bridge methods of the ported classes any still-binary class calls.

The port is a drop-in: ported classes shadow the 2002 ones on the classpath, and every method
whose Pizza signature mentioned a type parameter survives only under its mangled name
(`zeta$agl$Aggregate$reduce`).  Those mangled methods are the port's entire interface to the
remaining binary code, and `abi_gate.py` only checks that they are *present*.

This tool answers the other half: which of them anything actually calls.  A mangled method with
no binary caller is dead on arrival -- its bridge is reviewed, never executed, so a passing
oracle run says nothing about it.  That is worth knowing per class, because the honest claim
after a port is "the oracle covers these bridges, those are untested by construction".

Method names are unique strings in a class file's constant pool, so a byte-level search for the
mangled name finds every class that references it.  Classes that the port has replaced are
excluded from the search: a bridge called only from its own (replaced) class is not a caller.

    bridge_users.py [--ported port/classes] [--reference work/ref-classes]
"""
import argparse
import os
import re
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ZETA = os.path.dirname(HERE)
JAVAP = os.path.join(ZETA, "recovered/tools/jdk21/bin/javap")

MANGLED = re.compile(r"\b(zeta\$[A-Za-z0-9$]*\$[A-Za-z0-9_]+)\(")


def ported_classes(tree):
    out = []
    for dirpath, _d, files in os.walk(tree):
        for f in files:
            if f.endswith(".class"):
                rel = os.path.relpath(os.path.join(dirpath, f), tree)
                out.append(rel[: -len(".class")].replace(os.sep, "."))
    return sorted(out)


def mangled_members(classpath, cls):
    out = subprocess.run([JAVAP, "-protected", "-classpath", classpath, cls],
                         capture_output=True, text=True)
    names = []
    for line in out.stdout.split("\n"):
        m = MANGLED.search(line)
        if m and "$$" not in m.group(1):
            names.append(m.group(1))
    return sorted(set(names))


def class_files(tree, skip):
    for dirpath, _d, files in os.walk(tree):
        for f in files:
            if not f.endswith(".class"):
                continue
            path = os.path.join(dirpath, f)
            rel = os.path.relpath(path, tree)
            cls = rel[: -len(".class")].replace(os.sep, ".")
            if cls in skip:
                continue
            yield cls, path


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ported", default=os.path.join(ZETA, "port/classes"))
    ap.add_argument("--reference", default=os.path.join(ZETA, "work/ref-classes"))
    args = ap.parse_args()

    replaced = set(ported_classes(args.ported))
    blobs = [(cls, open(path, "rb").read())
             for cls, path in class_files(args.reference, replaced)]
    print("searching %d still-binary class(es)\n" % len(blobs))

    live = dead = 0
    for cls in sorted(replaced):
        names = mangled_members(args.ported, cls)
        if not names:
            continue
        print("%s" % cls)
        for name in names:
            needle = name.encode()
            users = sorted(c for c, b in blobs if needle in b)
            if users:
                live += 1
                shown = ", ".join(users[:4]) + (" ..." if len(users) > 4 else "")
                print("    called   %-44s %d caller(s): %s" % (name, len(users), shown))
            else:
                dead += 1
                print("    NOBODY   %s" % name)
        print()

    print("%d bridge(s) with a binary caller, %d with none" % (live, dead))
    return 0


if __name__ == "__main__":
    sys.exit(main())
