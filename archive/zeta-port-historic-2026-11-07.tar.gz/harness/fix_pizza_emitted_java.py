#!/usr/bin/env python3
"""Repair the Java that Pizza 1.1's `-s` emitter produces.

Pizza 1.1's own back-end type checker is broken on the ZETA sources: it reports ~100 errors,
every one preceded by Pizza's own banner "Suspicious error message -- there might be something
wrong with the Pizza->Java translation".  Front end and translation are clean, so the build uses
Pizza purely as a Pizza->Java translator (`-s`) and compiles the result with a real javac
(see zesurrect-plan.md §3).

The emitter has one defect that makes its output un-parseable.  For a `try` whose body is a
single *statement* rather than a block, it emits the statement without braces:

    try <stmt> catch (E e$0) { ... }

which is not legal Java.  The statement may span many lines (e.g. a whole if/else), so the
closing brace position is found by scanning for the `catch` keyword at brace depth 0, skipping
string and character literals and comments.  All occurrences come from Pizza's translation of
`fun`-expressions whose body throws a checked exception.

Note the emitted code must be compiled with `-source 1.4`: Pizza legitimately emits variables
named `enum`, which was not a keyword before Java 5.

Usage: fix_pizza_emitted_java.py <javasrc-root>     (idempotent; reports what it changed)
"""
import os
import re
import sys

TRY_NO_BLOCK = re.compile(r"(?<![A-Za-z0-9_$])try[ \t]+(?=[^ \t{])")


def _skip_literal_or_comment(text, i):
    """If text[i] starts a literal or comment, return the index just past it, else None."""
    n = len(text)
    c = text[i]
    if c in '"\'':
        i += 1
        while i < n:
            if text[i] == "\\":
                i += 2
                continue
            if text[i] == c:
                return i + 1
            i += 1
        return n
    if c == "/" and i + 1 < n and text[i + 1] == "/":
        j = text.find("\n", i)
        return n if j < 0 else j
    if c == "/" and i + 1 < n and text[i + 1] == "*":
        j = text.find("*/", i + 2)
        return n if j < 0 else j + 2
    return None


def _is_word_at(text, i, word):
    if not text.startswith(word, i):
        return False
    before = text[i - 1] if i else " "
    after = text[i + len(word):i + len(word) + 1] or " "
    return not (before.isalnum() or before in "_$") and not (after.isalnum() or after in "_$")


def _skip_ws(text, i):
    n = len(text)
    while i < n:
        if text[i].isspace():
            i += 1
            continue
        j = _skip_literal_or_comment(text, i)
        if j is not None and text[i] == "/":      # comment, not a literal
            i = j
            continue
        return i
    return n


def _skip_balanced(text, i, open_ch, close_ch):
    """text[i] must be open_ch; return the index just past the matching close_ch."""
    n, depth = len(text), 0
    while i < n:
        j = _skip_literal_or_comment(text, i)
        if j is not None:
            i = j
            continue
        if text[i] == open_ch:
            depth += 1
        elif text[i] == close_ch:
            depth -= 1
            if depth == 0:
                return i + 1
        i += 1
    return n


def find_catch_at_depth0(text, start):
    """Return the index of the `catch` that closes the brace-less try body starting at `start`.

    The body may itself be a try statement with its own catch clauses, e.g.

        try try { ... } catch (ZamIface.Fail e) { ... } catch (Failures.FormFailed e$0) { ... }

    where Java's grammar binds *both* catches to the inner try -- which is precisely why the
    output does not compile.  The two cannot be told apart structurally, so the closing catch is
    identified by Pizza's own naming convention: it mangles synthetic identifiers with '$', and
    the catch it generates for a brace-less try body always binds a parameter such as `e$0`.
    Catches whose parameter has an ordinary name come from ZETA source and belong to an inner
    try, so they are skipped.

    This convention is assumed, not documented by Pizza: it is verified only on the 11 sites in
    the ZETA sources, all of which close with `catch (Failures.FormFailed e$0)`.
    """
    depth = 0
    i, n = start, len(text)
    while i < n:
        j = _skip_literal_or_comment(text, i)
        if j is not None:
            i = j
            continue
        c = text[i]
        if c == "{":
            depth += 1
        elif c == "}":
            depth -= 1
            if depth < 0:                      # ran past the enclosing block: give up
                return None
        elif depth == 0 and _is_word_at(text, i, "catch"):
            k = _skip_ws(text, i + len("catch"))
            if k < n and text[k] == "(":
                end = _skip_balanced(text, k, "(", ")")
                if "$" in text[k:end]:         # Pizza's synthetic parameter: this is our catch
                    return i
                k = end
            k = _skip_ws(text, k)
            if k < n and text[k] == "{":
                k = _skip_balanced(text, k, "{", "}")
            i = k
            continue
        i += 1
    return None


def fix(text):
    """Wrap every brace-less try body in braces.  Returns (new_text, n_fixed)."""
    out, pos, fixed = [], 0, 0
    while True:
        m = TRY_NO_BLOCK.search(text, pos)
        if not m:
            out.append(text[pos:])
            break
        body = m.end()
        catch = find_catch_at_depth0(text, body)
        if catch is None:
            out.append(text[pos:body])
            pos = body
            continue
        out.append(text[pos:m.start()])
        out.append("try { ")
        out.append(text[body:catch].rstrip())
        out.append(" } ")
        fixed += 1
        pos = catch
    return "".join(out), fixed


def main():
    root = sys.argv[1]
    files = sites = 0
    for dirpath, _dirs, names in os.walk(root):
        for name in names:
            if not name.endswith(".java"):
                continue
            path = os.path.join(dirpath, name)
            with open(path, encoding="latin-1") as f:
                text = f.read()
            new, n = fix(text)
            if n:
                with open(path, "w", encoding="latin-1") as f:
                    f.write(new)
                files += 1
                sites += n
                print("  %s: %d try-without-block" % (os.path.relpath(path, root), n))
    print("\n%d sites wrapped in %d files" % (sites, files))


if __name__ == "__main__":
    main()
