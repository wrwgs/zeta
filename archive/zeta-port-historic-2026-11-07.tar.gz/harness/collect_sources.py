#!/usr/bin/env python3
"""Collect the ZETA source list the way etmake's `sources' target does:
from each node's ETMakefile PIZZA_FILES / JAVA_FILES variables.

Usage: collect_sources.py <src-root>
Prints one path per line, relative to <src-root>.
"""
import os
import re
import sys

root = sys.argv[1]


def read_makefile_vars(path):
    """Return {var: [tokens]} honouring backslash line continuations."""
    text = open(path, encoding="latin-1").read()
    text = re.sub(r"\\\n", " ", text)
    out = {}
    for line in text.splitlines():
        line = line.split("#", 1)[0]
        m = re.match(r"\s*([A-Za-z_]+)\s*:?\+?=\s*(.*)$", line)
        if m:
            out[m.group(1)] = m.group(2).split()
    return out


found, nodes_without_lists = [], []
for dirpath, dirnames, filenames in os.walk(root):
    if "ETMakefile" not in filenames:
        continue
    v = read_makefile_vars(os.path.join(dirpath, "ETMakefile"))
    rel = os.path.relpath(dirpath, root)
    listed = []
    for var in ("PIZZA_FILES", "JAVA_FILES"):
        for tok in v.get(var, []):
            if tok.startswith("$"):          # e.g. $(wildcard *.gif)
                continue
            listed.append(tok)
    if not listed:
        kind = " ".join(v.get("NODEKIND", []))
        local = [f for f in filenames if f.endswith((".pizza", ".java"))]
        if local:
            nodes_without_lists.append((rel, kind, local))
        continue
    for f in listed:
        p = os.path.join(rel, f) if rel != "." else f
        if os.path.exists(os.path.join(root, p)):
            found.append(p)
        else:
            print("MISSING: %s" % p, file=sys.stderr)

for rel, kind, local in nodes_without_lists:
    print("NO FILE LIST: %-28s kind=%-12s has %d sources: %s"
          % (rel, kind, len(local), " ".join(sorted(local))), file=sys.stderr)

for p in sorted(found):
    print(p)
