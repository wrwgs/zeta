#!/usr/bin/env python3
"""Check that nothing still binary references a member the port no longer provides.

The port is a drop-in: ported classes sit ahead of the 2002 `classes.jar` on the classpath, so
the running system is a mix that is never compiled together, only linked (zesurrect-plan.md
9.1).  A signature drift does not fail a build -- it fails at run time, as a NoSuchMethodError
or NoSuchFieldError somewhere far from the change, and only if that path happens to execute.
The oracle cannot be relied on to find it.

The question this tool answers is the exact one that matters, and no more:

    for every symbolic reference in every class that is STILL BINARY, does the runtime
    classpath (ported classes first, reference behind) still provide something it resolves to?

That is narrower and stricter than "the ported class kept every public member".  Narrower,
because a member no binary class names is free to change: `ArraySeq.elems` is package-private
and touched only by `ArraySeq`, `BufferSeq` and `ArraySeq`'s own enumerator, so once all three
are ported it can stop being a `pizza.support.array` and become a plain Java array.  An
earlier version of this gate compared declared member sets and would have forbidden that,
which would have forced Pizza's array wrapper through the whole sequence implementation for no
reason.  And stricter, because it resolves through the hierarchy the way the JVM does, so a
bridge a subclass no longer needs to redeclare is not reported as lost, while a reference to a
member that vanished from an inherited chain is.

References come from the constant pool: Fieldref/Methodref/InterfaceMethodref entries carry
owner class, name and descriptor exactly as the verifier will see them.  Reading them directly
is more precise than searching for name strings, which cannot tell `ArraySeq.elems` from
`HashSet$Change$IncludedAgg.elems`.

    abi_gate.py [--ported port/classes] [--reference work/ref-classes] [--verbose]

Exit status is non-zero if any reference fails to resolve.
"""
import argparse
import os
import re
import struct
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ZETA = os.path.dirname(HERE)
JAVAP = os.path.join(ZETA, "recovered/tools/jdk21/bin/javap")

GENERICS = re.compile(r"<[^<>]*(?:<[^<>]*>)?[^<>]*>")


# --------------------------------------------------------------------------- class file

ACC_FINAL = 0x0010
ACC_INTERFACE = 0x0200
ACC_ABSTRACT = 0x0400


def constant_pool(data, with_end=False):
    """Return the constant pool as a list, index 1..n (entry 0 is None).

    With `with_end`, also return the offset just past the pool, which is where the class's
    own access flags live.
    """
    if data[:4] != b"\xca\xfe\xba\xbe":
        raise ValueError("not a class file")
    count = struct.unpack_from(">H", data, 8)[0]
    pool = [None] * count
    i, pos = 1, 10
    while i < count:
        tag = data[pos]
        pos += 1
        if tag == 1:                                    # Utf8
            n = struct.unpack_from(">H", data, pos)[0]
            pool[i] = data[pos + 2: pos + 2 + n].decode("utf-8", "replace")
            pos += 2 + n
        elif tag in (7, 8, 16, 19, 20):                 # Class, String, MethodType, Module...
            pool[i] = ("ref1", tag, struct.unpack_from(">H", data, pos)[0])
            pos += 2
        elif tag in (9, 10, 11, 12, 17, 18):            # Fieldref..NameAndType, Dynamic
            pool[i] = ("ref2", tag) + struct.unpack_from(">HH", data, pos)
            pos += 4
        elif tag in (3, 4):                             # Integer, Float
            pos += 4
        elif tag in (5, 6):                             # Long, Double -- take two slots
            pos += 8
            i += 1
        elif tag == 15:                                 # MethodHandle
            pos += 3
        else:
            raise ValueError("unknown constant pool tag %d" % tag)
        i += 1
    return (pool, pos) if with_end else pool


def references(data):
    """Symbolic member references of one class: {(owner, name, descriptor, is_field)}."""
    pool = constant_pool(data)

    def utf8(idx):
        return pool[idx]

    def class_name(idx):
        entry = pool[idx]
        return utf8(entry[2]).replace("/", ".")

    out = set()
    for entry in pool:
        if not (isinstance(entry, tuple) and entry[0] == "ref2" and entry[1] in (9, 10, 11)):
            continue
        _k, tag, class_index, nat_index = entry
        nat = pool[nat_index]
        name, desc = utf8(nat[2]), utf8(nat[3])
        owner = class_name(class_index)
        if owner.startswith("["):                       # array type: members come from Object
            continue
        out.add((owner, name, desc, tag == 9))
    return out


def class_flags(data):
    """The class's own access flags, read straight out of the class file."""
    _pool, pos = constant_pool(data, with_end=True)
    return struct.unpack_from(">H", data, pos)[0]


def flag_report(name, ref_flags, new_flags, constructed_by, extended_by, mentioned_by):
    """Describe how a replaced class's own modifiers changed, and whether that can break.

    The gate resolves members, so without this it would be blind to the two changes the port
    actually makes on purpose -- sealing an ADT base (concrete -> abstract, so a `switch` over
    it can be exhaustive) and making its cases `final`. Both are safe exactly when no
    still-binary class does the thing the new modifier forbids, so the gate decides from that
    rather than from a list of exceptions:

      * became abstract  -- unsafe iff some binary class constructs it
      * became final     -- unsafe iff some binary class extends it
      * dropped abstract or final -- always safe, the new form is less restrictive
      * class <-> interface -- unsafe iff some binary class mentions the type at all; the
        change rewrites how every reference to it is resolved, so there is no finer test
        worth making

    ACC_ABSTRACT is ignored for a type that is an interface on both sides: Pizza did not set
    the flag on its interfaces (`zeta.agl.Enum` has ACC_INTERFACE without ACC_ABSTRACT),
    javac always does, and the difference means nothing to the verifier.
    """
    problems, notes = [], []
    was, now = ref_flags, new_flags
    if (was & ACC_INTERFACE) != (now & ACC_INTERFACE):
        if mentioned_by:
            problems.append("class/interface kind changed, and mentioned by %s"
                            % ", ".join(sorted(mentioned_by)))
        else:
            notes.append("class <-> interface (nothing binary mentions it)")
    elif (was & ACC_INTERFACE):
        return problems, notes          # an interface on both sides: no other flag matters
    if not (was & ACC_ABSTRACT) and (now & ACC_ABSTRACT):
        if constructed_by:
            problems.append("became abstract but constructed by %s"
                            % ", ".join(sorted(constructed_by)))
        else:
            notes.append("now abstract (nothing binary constructs it)")
    if not (was & ACC_FINAL) and (now & ACC_FINAL):
        if extended_by:
            problems.append("became final but extended by %s"
                            % ", ".join(sorted(extended_by)))
        else:
            notes.append("now final (nothing binary extends it)")
    return problems, notes


def mentions(data, known):
    """Class names this class mentions: Class constants, plus Utf8 strings naming a known class.

    The string case covers reflection -- ZETA loads its tool adaptors by name from `lib/zetarc`
    via Class.forName, so those classes have no Class constant pointing at them and would
    otherwise look unreachable.
    """
    pool = constant_pool(data)
    out = set()
    for entry in pool:
        if isinstance(entry, tuple) and entry[0] == "ref1" and entry[1] == 7:
            name = pool[entry[2]]
            if not name.startswith("["):
                out.add(name.replace("/", "."))
        elif isinstance(entry, str) and entry in known:
            out.add(entry)
    return out


ZETARC = os.path.join(ZETA, "run/zetabase/lib/zetarc")
# The 1.5 template of the plugin list.  Its active plugins are roots too, whether or not this
# machine's zetarc enables them: any of them can be loaded at run time with the shell's
# `plugin` command (zeta.tools.emacs.EditorAdaptor is the one not enabled here).
ZETARC_SITE = os.path.join(ZETA, "recovered/src/zeta-1.5/src/tools/sh/zetarc.site")
# Classes reached from outside the class graph: the shell is launched from a command line, and
# the tool adaptors are named in a TEXT file, so no class file mentions them at all.
EXTRA_ROOTS = ["zeta.tools.sh.Driver", "zeta.tools.sh.BatchCommander",
               "zeta.tools.sh.GuiCommander"]


def roots(paths=(ZETARC, ZETARC_SITE)):
    """Entry points: the shell drivers, plus every active `plugin <class>` line of zetarc and
    of the 1.5 zetarc template."""
    found = set(EXTRA_ROOTS)
    for path in paths:
        if os.path.exists(path):
            for line in open(path, encoding="latin-1"):
                parts = line.split()
                if len(parts) == 2 and parts[0] == "plugin":
                    found.add(parts[1])
    return found


def dead_classes(binary, ported):
    """Binary classes that nothing live can reach any more.

    Pizza compiled each `fun (...)->...` literal into a generated `X$$closures` subclass whose
    only referrer is X itself.  Porting X deletes the lifted `$closure$...` statics the
    generated class calls, so that class is left holding references that no longer resolve --
    and it is also unreachable, because the only code that ever instantiated it was the method
    bodies in X that the port replaced.  A dangling reference inside an unreachable class
    cannot fail at run time, so it must not fail the gate either; reporting it would make the
    gate cry wolf on every class that had closure literals, which is most of AGL.

    Dead means: not reachable, along "class A mentions class B" edges, from a root or from any
    ported class (ported classes are always live).  Computed as reachability, not as the fixpoint
    "every class that mentions it is dead": that least fixpoint cannot kill a *cycle*, because
    each member of an unreachable cycle keeps the other "mentioned".  It first bit when
    zeta.tools.sh.LogPanel was ported: Pizza's `LogPanel$3$$anonymous_class2` and its own nested
    `...$5$$anonymous_class4` mention each other and nothing live mentions either, yet the old
    computation kept both alive and reported their stale call to the 2002 `LogPanel.access$000`
    as a broken reference.  On acyclic chains the two definitions agree, so this only removes
    cycle false positives -- a reference from anything reachable is still checked.

    Entry points must be excluded explicitly.  "Nothing mentions it" is true of
    `zeta.tools.sh.Driver`, which is named on a java command line, and of the tool adaptors,
    which are named in the text of `lib/zetarc` and loaded by reflection -- no class file holds
    their names even as strings.  Classifying one of those as dead would silently excuse a real
    broken reference, so `roots()` seeds them as live.
    """
    known = set(binary) | set(ported)
    mentions_of = {}
    for cls, path in list(binary.items()) + list(ported.items()):
        try:
            mentions_of[cls] = {t for t in mentions(open(path, "rb").read(), known) if t != cls}
        except ValueError:
            # unreadable class file: treat it as mentioning nothing, as before
            mentions_of[cls] = set()
    live = set(ported) | (roots() & known)
    frontier = list(live)
    while frontier:
        cls = frontier.pop()
        for target in mentions_of.get(cls, ()):
            if target not in live:
                live.add(target)
                frontier.append(target)
    return set(binary) - live


FIELD = re.compile(r"^(?!.*\()(?P<mods>[\w ]*?)\s*(?P<type>[\w.$\[\]<>]+)\s+(?P<name>[\w$]+);$")


def public_instance_fields_via(view, cls):
    """Public, non-static fields of `cls` in class-file order, from a Classpath's cache.

    Folded into `Classpath._load` rather than run as its own `javap` pass: the gate was doing
    three passes per replaced class and had become the slowest step of the verification loop.
    """
    info = view.of(cls)
    return None if info is None else info[2]


def public_instance_fields(classpath, cls):
    """Public, non-static fields of `cls` in CLASS FILE ORDER.

    Order is part of the observable behaviour, not a detail. `zeta.util.Term.toFormat` renders
    a term by walking `getClass().getFields()`, skips any name containing `$` -- so the `$$tag`
    field is invisible -- and picks the closing separator with `i == subterms.length - 1`, an
    index into *all* the fields including the skipped ones. So whether the tag happens to be
    last decides whether any field gets the closing ")" at all.

    Pizza appends `$$tag` after the fields declared in the source. Writing it first, which
    reads better, changed every `text` artifact and several `absy` ones.
    """
    out = subprocess.run([JAVAP, "-p", "-classpath", classpath, cls],
                         capture_output=True, text=True)
    if out.returncode != 0:
        return None
    fields = []
    for line in out.stdout.split("\n"):
        t = " ".join(line.split())
        if not t or "(" in t or not t.endswith(";"):
            continue
        m = FIELD.match(_erase(t))
        if m and "public" in m.group("mods") and "static" not in m.group("mods"):
            fields.append(m.group("name"))
    return fields


def classes_in(tree):
    found = {}
    for dirpath, _d, files in os.walk(tree):
        for f in files:
            if f.endswith(".class"):
                path = os.path.join(dirpath, f)
                rel = os.path.relpath(path, tree)
                found[rel[: -len(".class")].replace(os.sep, ".")] = path
    return found


# --------------------------------------------------------------------------- javap view

def _erase(text):
    prev = None
    while prev != text:
        prev = text
        text = GENERICS.sub("", text)
    return text


class Classpath:
    """The members and supertypes of each class, as the runtime classpath presents them."""

    def __init__(self, path):
        self.path = path
        self._cache = {}

    def of(self, cls):
        if cls not in self._cache:
            self._cache[cls] = self._load(cls)
        return self._cache[cls]

    def _load(self, cls):
        out = subprocess.run([JAVAP, "-p", "-s", "-classpath", self.path, cls],
                             capture_output=True, text=True)
        if out.returncode != 0:
            return None
        simple = cls.split(".")[-1]          # javap prints nested names as Outer$Inner
        members, supers, fields, pending = set(), [], [], None
        for line in out.stdout.split("\n"):
            t = " ".join(line.split())
            if not t or t.startswith("Compiled from") or t == "}":
                continue
            if t.startswith("descriptor:"):
                if pending is not None:
                    members.add((pending, t.split(" ", 1)[1]))
                    pending = None
                continue
            t = _erase(t).rstrip(";").strip()
            if " class " in " " + t or " interface " in " " + t:
                for kw in ("extends", "implements"):
                    if (" %s " % kw) in t:
                        tail = t.split(" %s " % kw, 1)[1]
                        tail = tail.split(" implements ")[0].rstrip(" {")
                        supers += [s.strip() for s in tail.split(",") if s.strip()]
                continue
            if "(" in t:
                # Distinguish a constructor from a static factory of the SAME NAME by whether
                # a return type is present:
                #
                #   public zeta...Fixity(int, boolean, Component[])            <- constructor
                #   public static zeta...Fixity Fixity(int, boolean, ...)      <- factory
                #
                # Every Pizza single-case class has both, because the case name equals the
                # class name.  Treating the factory as a constructor made the gate unable to
                # check any of them -- it reported `Fixity.Fixity` unresolved when the ported
                # class had it, and would equally have missed one that was genuinely absent.
                head = [w for w in t.split("(")[0].split()
                        if w not in ("public", "protected", "private", "static", "final",
                                     "abstract", "synchronized", "native", "default",
                                     "transient", "volatile", "strictfp")]
                name = head[-1] if head else t.split("(")[0].strip()
                if len(head) == 1 and name.split(".")[-1] == simple:
                    name = "<init>"
            else:
                name = t.split()[-1]
                m = FIELD.match(t)
                if m and "public" in m.group("mods") and "static" not in m.group("mods"):
                    fields.append(m.group("name"))
            pending = name
        if "java.lang.Object" not in supers and cls != "java.lang.Object":
            supers.append("java.lang.Object")
        return members, supers, fields

    def resolves(self, owner, name, desc):
        """Does `owner` provide `name desc`, directly or by inheritance?"""
        seen, work = set(), [owner]
        while work:
            cls = work.pop(0)
            if cls in seen:
                continue
            seen.add(cls)
            info = self.of(cls)
            if info is None:
                continue
            members, supers, _fields = info
            if (name, desc) in members:
                return True
            work += supers
        return False


# --------------------------------------------------------------------------- main

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ported", default=os.path.join(ZETA, "port/classes"))
    ap.add_argument("--reference", default=os.path.join(ZETA, "work/ref-classes"))
    ap.add_argument("--verbose", action="store_true",
                    help="also list reference members the port dropped and nobody references")
    args = ap.parse_args()

    ported = classes_in(args.ported)
    reference = classes_in(args.reference)
    runtime = Classpath(args.ported + os.pathsep + args.reference)
    refview = Classpath(args.reference)

    # every reference made by a class that is still binary
    binary = {c: p for c, p in reference.items() if c not in ported}
    refs = {}
    for cls, path in sorted(binary.items()):
        try:
            for ref in references(open(path, "rb").read()):
                refs.setdefault(ref, []).append(cls)
        except ValueError as e:
            print("WARNING cannot read %s: %s" % (cls, e))

    # only references into classes the port replaced can have been broken by the port
    interesting = {r: who for r, who in refs.items() if r[0] in ported}
    dead = dead_classes(binary, ported)

    # what still-binary classes construct, extend and mention, for judging modifier changes
    constructed, extended, mentioners = {}, {}, {}
    known = set(binary) | set(ported)
    for cls, path in sorted(binary.items()):
        try:
            blob = open(path, "rb").read()
            for owner, name, desc, isf in references(blob):
                if name == "<init>":
                    constructed.setdefault(owner, set()).add(cls)
            for target in mentions(blob, known):
                if target != cls:
                    mentioners.setdefault(target, set()).add(cls)
        except ValueError:
            continue
        info = runtime.of(cls)
        if info:
            for sup in info[1]:
                extended.setdefault(sup, set()).add(cls)

    flag_bad, flag_notes = [], []
    for cls in sorted(ported):
        if cls not in reference:
            continue
        try:
            ref_flags = class_flags(open(reference[cls], "rb").read())
            new_flags = class_flags(open(ported[cls], "rb").read())
        except ValueError:
            continue
        problems, notes = flag_report(cls, ref_flags, new_flags,
                                      constructed.get(cls, set()) - set(ported),
                                      extended.get(cls, set()) - set(ported),
                                      mentioners.get(cls, set()) - set(ported))
        flag_bad += [(cls, m) for m in problems]
        flag_notes += [(cls, m) for m in notes]

    bad, in_dead = [], []
    for (owner, name, desc, _is_field), who in sorted(interesting.items()):
        if runtime.resolves(owner, name, desc):
            continue
        live = [c for c in who if c not in dead]
        (bad if live else in_dead).append((owner, name, desc, live or who))

    per_class = {}
    for (owner, name, desc, _f) in interesting:
        per_class.setdefault(owner, 0)
        per_class[owner] += 1
    for cls in sorted(ported):
        if cls not in reference:
            print("new  %-50s (nothing binary can reference it)" % cls)
        else:
            print("ok   %-50s %d reference(s) from binary classes resolve"
                  % (cls, per_class.get(cls, 0)))

    for owner, name, desc, who in bad:
        print("\nFAIL %s.%s %s" % (owner, name, desc))
        print("     referenced by: %s%s"
              % (", ".join(who[:6]), " ..." if len(who) > 6 else ""))

    # Field order matters only where something can observe it: a binary class that reads the
    # fields, or the reflective renderers (`Term.toFormat`, `FormatPrinter.buildFormat`),
    # which only ever see an object that binary code handed over.  A type nothing binary
    # mentions cannot be observed either way -- `HashSet$Change` and `HashMap$Change` are
    # private change records, and the port replaces them with field-less interfaces.
    order_bad, order_notes = [], []
    for cls in sorted(ported):
        if cls not in reference:
            continue
        was = public_instance_fields_via(refview, cls)
        now = public_instance_fields_via(runtime, cls)
        if was is None or now is None or was == now:
            continue
        if mentioners.get(cls, set()) - set(ported):
            order_bad.append((cls, was, now))
        else:
            order_notes.append("%s: %s -> %s (nothing binary mentions it)"
                               % (cls, ", ".join(was) or "(none)", ", ".join(now) or "(none)"))

    for cls, msg in flag_bad:
        print("\nFAIL %s: %s" % (cls, msg))

    for cls, was, now in order_bad:
        print("\nFAIL %s: public instance fields differ in order or content" % cls)
        print("     reference: %s" % ", ".join(was))
        print("     ported   : %s" % ", ".join(now))
    if flag_notes or order_notes:
        print("\nmodifier and field changes, each shown safe by what no binary class does:")
        for cls, msg in flag_notes:
            print("    %-54s %s" % (cls, msg))
        for msg in order_notes:
            print("    %s" % msg)

    if args.verbose:
        print("\nreference members the port no longer provides, and nobody references:")
        for cls in sorted(c for c in ported if c in reference):
            info = refview.of(cls)
            if info is None:
                continue
            for name, desc in sorted(info[0]):
                if not runtime.resolves(cls, name, desc):
                    print("    %s.%s %s" % (cls, name, desc))

    if in_dead:
        holders = sorted({c for _o, _n, _d, who in in_dead for c in who})
        print("\n%d unresolved reference(s), all inside class(es) nothing live can reach:"
              % len(in_dead))
        for c in holders:
            print("    %-56s %s" % (c, "(Pizza-generated)" if "$$" in c else
                                    "<-- NOT generated: check this really is unreachable"))
    if dead and args.verbose:
        print("\n%d binary class(es) classified unreachable:" % len(dead))
        for c in sorted(dead):
            print("    %s" % c)

    print("\n%d class(es) replaced, %d reference(s) checked, %d unresolved, "
          "%d unresolved but unreachable, %d bad modifier change(s), %d field-order change(s)"
          % (len(ported), len(interesting), len(bad), len(in_dead), len(flag_bad),
             len(order_bad)))
    return 1 if (bad or flag_bad or order_bad) else 0


if __name__ == "__main__":
    sys.exit(main())
