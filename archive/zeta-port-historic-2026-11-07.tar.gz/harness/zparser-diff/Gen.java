import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.List;

import zeta.agl.Aggregate;
import zeta.agl.HashMap;
import zeta.content.text.Lexem;
import zeta.content.text.Text;
import zeta.content.zirp.DeclAttr;
import zeta.content.zirp.Fixity;
import zeta.content.zirp.UnitEnv;
import zeta.format.Format;
import zeta.format.FormatInfo;
import zeta.session.Diag;
import zeta.session.Locator;
import zeta.tools.latex.LatexConfig;
import zeta.tools.latex.TextLocator;
import zeta.tools.zparser.ItemParser;
import zeta.tools.zparser.UnitParser;
import zeta.util.AnnotatedTerm;
import zeta.util.Name;

/** Runs inside one class loader: parses each spec, returns a rendering per spec. */
public class Gen {

  static final Name FILE = new Name("f");
  static int pos;

  static Locator loc() {
    pos++;
    return new TextLocator(FILE, pos, 1, pos, 2);
  }

  static Lexem lexem(String spec) throws Exception {
    String kind = spec.substring(0, 2);
    String arg = spec.substring(2);
    switch (kind) {
      case "W:": return new Lexem.Word(arg);
      case "N:": return new Lexem.Number(arg);
      case "D:": return new Lexem.Denotation(arg);
      case "S:": return new Lexem.StrokeIndex(arg);
      case "M:": return new Lexem.MacroArg(arg);
      case "L:": return (Lexem) Lexem.class.getField(arg).get(null);
      default: throw new Error(spec);
    }
  }

  static Text.ZedToken[] tokens(String s) throws Exception {
    List<Text.ZedToken> r = new ArrayList<>();
    for (String t : s.trim().split(" ")) {
      if (t.isEmpty()) continue;
      Text.ZedToken z = (Text.ZedToken) Text.ZedToken(lexem(t));
      z.locator = loc();
      r.add(z);
    }
    return r.toArray(new Text.ZedToken[0]);
  }

  static Fixity[] fixities() {
    return new Fixity[]{
      new Fixity(30, false, new Fixity.Component[]{
        Fixity.Component.Operand(30), Fixity.Component.Keyword(new Name("+")),
        Fixity.Component.Operand(31)}),
      new Fixity(30, false, new Fixity.Component[]{
        Fixity.Component.Operand(30), Fixity.Component.Keyword(new Name("cup")),
        Fixity.Component.Operand(31)}),
      new Fixity(40, false, new Fixity.Component[]{
        Fixity.Component.Operand(40), Fixity.Component.Keyword(new Name("*")),
        Fixity.Component.Operand(41)}),
      new Fixity(90, false, new Fixity.Component[]{
        Fixity.Component.Keyword(new Name("-")), Fixity.Component.Operand(90)}),
      new Fixity(100, false, new Fixity.Component[]{
        Fixity.Component.Operand(100), Fixity.Component.Keyword(new Name("~"))}),
      new Fixity(-1, false, new Fixity.Component[]{
        Fixity.Component.Operand(-1), Fixity.Component.Keyword(new Name("<")),
        Fixity.Component.Operand(-1)}),
      new Fixity(-1, false, new Fixity.Component[]{
        Fixity.Component.Operand(-1), Fixity.Component.Keyword(new Name("=")),
        Fixity.Component.Operand(-1)}),
      new Fixity(-1, false, new Fixity.Component[]{
        Fixity.Component.Keyword(new Name("disjoint")), Fixity.Component.Operand(-1)}),
      new Fixity(20, false, new Fixity.Component[]{
        Fixity.Component.OperandList(new Name("langle"), new Name("rangle"))}),
      new Fixity(80, true, new Fixity.Component[]{
        Fixity.Component.Keyword(new Name("P1")), Fixity.Component.Operand(80)}),
      new Fixity(10, false, new Fixity.Component[]{
        Fixity.Component.Keyword(new Name("IF2")), Fixity.Component.Operand(10),
        Fixity.Component.Keyword(new Name("THEN2")), Fixity.Component.Operand(10)}),
      new Fixity(50, true, new Fixity.Component[]{
        Fixity.Component.Operand(50), Fixity.Component.Keyword(new Name("rel")),
        Fixity.Component.Operand(51)}),
    };
  }

  static Object[][] macros() throws Exception {
    return new Object[][]{
      {"m0", 0, "W:x W:+ W:y"},
      {"m1", 1, "L:Lparenth M:#1 W:* M:#1 L:Rparenth"},
      {"m2", 2, "M:#1 W:< M:#2"},
      {"mm", 1, "W:m1 L:Lgroup M:#1 L:Rgroup"},
      {"rec", 0, "W:rec"},
    };
  }

  static Lexem[] lexems(String s) throws Exception {
    List<Lexem> r = new ArrayList<>();
    for (String t : s.split(" ")) r.add(lexem(t));
    return r.toArray(new Lexem[0]);
  }

  static UnitEnv env() throws Exception {
    UnitEnv env = UnitEnv.newSection(new Name("U"), loc());
    for (Fixity f : fixities()) env.declareFixity(loc(), f);
    for (Object[] m : macros())
      env.declareMacro(loc(), new Name((String) m[0]), (Integer) m[1], lexems((String) m[2]));
    env.getAndClearDiag();
    return env;
  }

  public static List<String> run(List<String> specs) {
    List<String> out = new ArrayList<>();
    for (String spec : specs) {
      pos = 0;
      StringBuilder sb = new StringBuilder();
      try {
        String[] f = spec.split("\u0001", -1);
        switch (f[0]) {
          case "EXPR": {
            ItemParser.ParseResult r =
              ItemParser.parseExpr(new LatexConfig(), env(), tokens(f[1]));
            sb.append("diag: "); dump(r.diag, sb, 0);
            sb.append("\nterm: "); dump(r.term, sb, 0);
            break;
          }
          case "PRED": {
            ItemParser.ParseResult r =
              ItemParser.parsePredicate(new LatexConfig(), env(), tokens(f[1]));
            sb.append("diag: "); dump(r.diag, sb, 0);
            sb.append("\nterm: "); dump(r.term, sb, 0);
            break;
          }
          case "UNIT": {
            List<Text> subs = new ArrayList<>();
            for (Fixity fx : fixities()) {
              Text t = Text.ZedFixity(fx);
              t.locator = loc();
              subs.add(t);
            }
            for (Object[] m : macros()) {
              Text t = Text.ZedMacro(new Name((String) m[0]), (Integer) m[1],
                                     lexems((String) m[2]));
              t.locator = loc();
              subs.add(t);
            }
            for (int i = 1; i + 3 < f.length; i += 4) {
              Text.ZedMarkupKind kind = (Text.ZedMarkupKind)
                Text.ZedMarkupKind.class.getField(f[i]).get(null);
              Text t = Text.ZedMarkup(kind, tokens(f[i+1]), tokens(f[i+2]), tokens(f[i+3]));
              t.locator = loc();
              subs.add(t);
            }
            Text sec = Text.ZedSection(new Name("U"), new Name[0], subs.toArray(new Text[0]));
            sec.locator = loc();
            UnitEnv env = UnitEnv.newSection(new Name("U"), sec.locator);
            UnitParser p = new UnitParser(new LatexConfig(), env, new HashMap());
            Object absy = p.run(sec);
            sb.append("diag: "); dump(p.getAndClearDiag(), sb, 0);
            sb.append("\nenvdiag: "); dump(env.getAndClearDiag(), sb, 0);
            sb.append("\nabsy: "); dump(absy, sb, 0);
            break;
          }
          case "XTR": {
            List<Text> subs = new ArrayList<>();
            for (String t : f[1].trim().split(" ")) {
              if (t.isEmpty()) continue;
              Text x;
              if (t.startsWith("I:")) x = Text.ModelInclusion(new Name(t.substring(2)));
              else if (t.startsWith("U:")) x = Text.ZedMarkup(Text.ZedMarkupKind.Unboxed,
                  new Text[0], new Text[0], tokens(t.substring(2).replace(',', ' ')));
              else if (t.startsWith("K:")) x = Text.DocMarkup("itemize", new String[0],
                  tokens(t.substring(2).replace(',', ' ')));
              else x = Text.ZedToken(lexem(t));
              x.locator = loc();
              subs.add(x);
            }
            Text[] arr = subs.toArray(new Text[0]);
            sb.append("incs: ");
            try { dump(UnitParser.extractInclusions(arr), sb, 0); }
            catch (Throwable t) { sb.append("EXC " + t.getClass().getName()); }
            sb.append(" enr: ");
            try { dump(UnitParser.extractEnriched((Text.ZedClass) Text.ZedClass(new Name("C"),
                    new Name[0], new Name[0], arr)), sb, 0); }
            catch (Throwable t) { sb.append("EXC " + t.getClass().getName()); }
            break;
          }
          default: throw new Error(f[0]);
        }
      } catch (Throwable t) {
        sb.append("\nEXC ").append(t.getClass().getName());
        if (System.getProperty("gen.trace") != null) t.printStackTrace();
      }
      out.add(sb.toString());
    }
    return out;
  }

  static void dump(Object o, StringBuilder sb, int depth) {
    if (depth > 300) { sb.append("..."); return; }
    if (o == null) { sb.append("null"); return; }
    if (o instanceof String || o instanceof Number || o instanceof Boolean) {
      sb.append(o); return;
    }
    if (o instanceof Name) { sb.append("N(").append(o).append(')'); return; }
    if (o instanceof Locator l) { sb.append('@').append(l.toFormat(new FormatInfo())); return; }
    if (o instanceof Format fm) { sb.append("F<").append(fm.toString()).append('>'); return; }
    if (o instanceof Diag d) {
      sb.append("Diag[");
      for (Diag.Item it : d.getItems()) {
        dump(it.locator, sb, depth + 1); sb.append(' ');
        sb.append(it.category.toFormat(new FormatInfo())).append(' ');
        sb.append(it.message.toString()).append("; ");
      }
      sb.append(']');
      return;
    }
    if (o.getClass().isArray()) {
      sb.append('[');
      int n = java.lang.reflect.Array.getLength(o);
      for (int i = 0; i < n; i++) {
        if (i > 0) sb.append(", ");
        dump(java.lang.reflect.Array.get(o, i), sb, depth + 1);
      }
      sb.append(']');
      return;
    }
    if (o instanceof Aggregate a) {
      dump(a.toArray(Object.class), sb, depth + 1);
      return;
    }
    String cn = o.getClass().getName();
    sb.append(cn.substring(cn.lastIndexOf('.') + 1));
    if (o instanceof AnnotatedTerm at) {
      sb.append(" @");
      Locator l = Locator.get(at.an);
      sb.append(l == null ? "-" : l.toFormat(new FormatInfo()).toString());
      DeclAttr da = DeclAttr.get(at.an);
      if (da != null) { sb.append(" attr="); dump(da, sb, depth + 1); }
    }
    sb.append('(');
    for (Field fd : o.getClass().getFields()) {
      if (Modifier.isStatic(fd.getModifiers())) continue;
      if (fd.getName().contains("$")) continue;
      if (fd.getName().equals("an")) continue;
      sb.append(fd.getName()).append('=');
      try { dump(fd.get(o), sb, depth + 1); } catch (Exception e) { sb.append("?"); }
      sb.append(' ');
    }
    sb.append(')');
  }
}
