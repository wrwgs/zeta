#!/bin/sh
# Differential gate for zeta.tools.zparser: random and mutated specifications through the
# 2002 parser and through the ported one, on the same ported base, compared on abstract
# syntax, locators, DeclAttr annotations, diagnostics in order, and exception class.
#
# Why it exists: no input in the corpus exercises the parser's error paths, so the baselines
# cannot see a regression there.  Written by the zparser port (2026-11-06), where 300,000+
# inputs matched except two 1998 crashes that the port fixes (UnitParser.extractInclusions
# recursion, trailing \Enrich read past the end) -- those show up here as differences in
# which the reference throws.
#
# STATUS (2026-11-07): historical.  The reference side loads the 2002 zparser classes onto the
# ported base, and those classes call the Pizza-mangled bridges and pizza.* runtime that the
# final pass removed -- so on the current tree the reference side cannot link.  The comparison
# was run on the integrated batch-1 build (30,000 specs, differNotFixedCrash=0) before the
# bridges went; regressions in the parser are now caught by the ported oracle and the negative
# suites.  To rerun it, build the reference base from a tree that still has the bridge layer.
#
# Pass criterion: the summary line reports differNotFixedCrash=0.  `differ` counts inputs
# where the reference crashes in one of the two fixed ways and the port does not; exceptions
# listed in the summary occur identically on both sides (1998 crashes the port preserves).
#
# Usage: harness/zparser-diff/run.sh [SEED [N]]       (defaults 1, 30000)
# Reads port/classes; do not run it while build-port.sh is running.
set -e
ZETA=$(cd "$(dirname "$0")/../.." && pwd)
JDK=$ZETA/recovered/tools/jdk21/bin
SEED=${1:-1}
N=${2:-30000}
W=$(mktemp -d)
trap 'rm -rf "$W"' EXIT

# reference side: the current ported base, minus the ported parser, so the 2002 zparser
# classes in work/ref-classes are the ones that load
cp -a "$ZETA/port/classes" "$W/base-ref"
rm -rf "$W/base-ref/zeta/tools/zparser"

mkdir -p "$W/gen" "$W/main"
"$JDK/javac" -nowarn -encoding latin1 -cp "$ZETA/port/classes:$ZETA/work/ref-classes" \
    -d "$W/gen" "$ZETA/harness/zparser-diff/Gen.java"
"$JDK/javac" -nowarn -encoding latin1 -d "$W/main" "$ZETA/harness/zparser-diff/DiffMain.java"

"$JDK/java" -cp "$W/main" DiffMain \
    "$W/gen:$W/base-ref:$ZETA/work/ref-classes" \
    "$W/gen:$ZETA/port/classes:$ZETA/work/ref-classes" \
    "$SEED" "$N"
