import java.io.File;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** Differential driver: same specs through the 2002 parser and through the port. */
public class DiffMain {

  static Random rnd;

  // ---- token spec generation ----------------------------------------------------------

  static final String[] NAMES = {"W:x", "W:y", "W:S", "W:f", "W:T"};
  static final String[] ALPHABET = {
    "W:x", "W:y", "W:S", "W:+", "W:*", "W:-", "W:~", "W:<", "W:=", "W:disjoint",
    "W:langle", "W:rangle", "W:P1", "W:IF2", "W:THEN2", "W:cup", "W:rel", "N:1", "D:\"d\"",
    "S:_1", "M:#1",
    "L:Lparenth", "L:Rparenth", "L:Lbrack", "L:Rbrack", "L:Lset", "L:Rset", "L:Lbind",
    "L:Rbind", "L:Comma", "L:Colon", "L:Semi", "L:Mid", "L:Spot", "L:Defeq", "L:Defsyn",
    "L:Linesep", "L:And", "L:Or", "L:Implies", "L:Iff", "L:Not", "L:Forall", "L:Exists",
    "L:Exists1", "L:Lambda", "L:Mu", "L:Let", "L:If", "L:Then", "L:Else", "L:Theta",
    "L:Delta", "L:Xi", "L:Pre", "L:Hide", "L:Project", "L:Pipe", "L:Compose", "L:Cross",
    "L:Power", "L:StrokeIn", "L:StrokeOut", "L:StrokePrime", "L:Dot", "L:Slash",
    "L:Lgroup", "L:Rgroup", "L:True", "L:False", "L:Arg", "L:ListArg", "L:Ldata",
    "L:Rdata", "L:Enrich", "L:Input", "L:Derived", "L:Data", "L:Port", "L:Property",
    "L:Init", "L:BasicState", "L:RefState", "L:Connector", "L:When", "L:Goto",
    "L:TransLabel", "L:Lstate", "L:Rstate", "L:Ltrans", "L:Rtrans", "L:Duration",
    "L:Length", "L:Everywhere", "L:Somewhere", "L:Await", "L:Repeat", "L:Prefix",
    "L:Chop", "L:FollowedBy", "L:Leadsto", "L:Trans", "L:Aggreg", "L:Assoc", "L:Choice",
    "L:Compute", "L:Dyn", "L:Flow", "L:Internflow", "L:Lbind", "L:LeftAssoc",
    "L:RightAssoc", "L:Preempt", "L:To", "L:XorState", "L:AndState", "L:Lglue", "L:Rglue",
    "W:m0", "W:m1", "W:m2", "W:mm", "W:rec", "M:#2", "L:Lgroup", "L:Rgroup"
  };

  static String pick(String... a) { return a[rnd.nextInt(a.length)]; }

  static void name(List<String> o) { o.add(pick(NAMES)); }

  static void expr(List<String> o, int d) {
    int k = d <= 0 ? rnd.nextInt(3) : rnd.nextInt(40);
    switch (k) {
      case 0: name(o); break;
      case 1: if (rnd.nextInt(3) == 0) { o.add(pick("W:m0", "W:rec")); break; }
              if (rnd.nextInt(3) == 0) { o.add(pick("W:m1", "W:mm")); o.add("L:Lgroup");
                expr(o, d-1); o.add("L:Rgroup"); break; }
              o.add("N:1"); break;
      case 2: o.add("D:\"d\""); break;
      case 3: o.add("L:Lparenth"); expr(o, d-1); o.add("L:Rparenth"); break;
      case 4: o.add("L:Lparenth"); expr(o, d-1); o.add("L:Comma"); expr(o, d-1);
              o.add("L:Rparenth"); break;
      case 5: expr(o, d-1); o.add("W:+"); expr(o, d-1); break;
      case 6: expr(o, d-1); o.add("W:*"); expr(o, d-1); break;
      case 7: o.add("W:-"); expr(o, d-1); break;
      case 8: expr(o, d-1); o.add("W:~"); break;
      case 9: o.add("L:Lset"); exprList(o, d-1); o.add("L:Rset"); break;
      case 10: o.add("L:Lset"); decls(o, d-1); if (rnd.nextBoolean()) { o.add("L:Mid");
               pred(o, d-1); } if (rnd.nextBoolean()) { o.add("L:Spot"); expr(o, d-1); }
               o.add("L:Rset"); break;
      case 11: o.add("L:Lbrack"); decls(o, d-1); if (rnd.nextBoolean()) { o.add("L:Mid");
               props(o, d-1); } o.add("L:Rbrack"); break;
      case 12: o.add("W:langle"); if (rnd.nextBoolean()) exprList(o, d-1); o.add("W:rangle");
               break;
      case 13: o.add("L:Power"); expr(o, d-1); break;
      case 14: expr(o, d-1); o.add("L:Cross"); expr(o, d-1); break;
      case 15: o.add(pick("L:Lambda", "L:Mu", "L:Let")); decls(o, d-1);
               if (rnd.nextBoolean()) { o.add("L:Mid"); pred(o, d-1); }
               o.add("L:Spot"); expr(o, d-1); break;
      case 16: o.add("L:Lparenth"); o.add("L:Mu"); decls(o, d-1);
               if (rnd.nextBoolean()) { o.add("L:Spot"); expr(o, d-1); }
               o.add("L:Rparenth"); break;
      case 17: o.add("L:If"); pred(o, d-1); o.add("L:Then"); expr(o, d-1); o.add("L:Else");
               expr(o, d-1); break;
      case 18: o.add(pick("L:Theta", "L:Xi", "L:Pre", "L:Delta", "L:Not")); expr(o, d-1);
               break;
      case 19: o.add("L:Delta"); o.add("L:Lparenth"); nameList(o); o.add("L:Rparenth");
               expr(o, d-1); break;
      case 20: expr(o, d-1); o.add("L:Dot"); if (rnd.nextBoolean()) o.add("N:1"); else name(o);
               break;
      case 21: expr(o, d-1); o.add("L:Lbrack"); name(o); o.add("L:Slash"); name(o);
               if (rnd.nextBoolean()) { o.add("L:Comma"); name(o); o.add("L:Slash");
               name(o); } o.add("L:Rbrack"); break;
      case 22: expr(o, d-1); o.add("L:Hide"); o.add("L:Lparenth"); nameList(o);
               o.add("L:Rparenth"); break;
      case 23: expr(o, d-1); o.add(pick("L:Project", "L:Compose", "L:Pipe", "L:And", "L:Or",
               "L:Implies", "L:Iff")); expr(o, d-1); break;
      case 24: expr(o, d-1); o.add(pick("L:StrokeIn", "L:StrokeOut", "L:StrokePrime",
               "S:_1")); break;
      case 25: o.add("L:Lbind"); if (rnd.nextBoolean()) { name(o); o.add("L:Defeq");
               expr(o, d-1); if (rnd.nextBoolean()) { o.add("L:Comma"); name(o);
               o.add("L:Defeq"); expr(o, d-1); } } o.add("L:Rbind"); break;
      case 26: name(o); o.add("L:Lbrack"); exprList(o, d-1); o.add("L:Rbrack"); break;
      case 27: o.add(pick("L:Forall", "L:Exists", "L:Exists1")); decls(o, d-1);
               if (rnd.nextBoolean()) { o.add("L:Mid"); pred(o, d-1); }
               o.add("L:Spot"); expr(o, d-1); break;
      case 28: name(o); expr(o, d-1); break;
      case 29: o.add("W:P1"); expr(o, d-1); break;
      case 30: o.add("W:IF2"); expr(o, d-1); o.add("W:THEN2"); expr(o, d-1); break;
      case 31: expr(o, d-1); o.add("W:cup"); expr(o, d-1); break;
      case 32: o.add("L:Lgroup"); expr(o, d-1); o.add("L:Rgroup"); break;
      case 33: o.add("L:Lparenth"); mixName(o); o.add("L:Rparenth"); break;
      case 34: expr(o, d-1); o.add("W:rel"); expr(o, d-1); break;
      case 35: o.add("L:Lparenth"); o.add("W:+"); o.add("L:Rparenth");
               if (rnd.nextBoolean()) { o.add("L:Lbrack"); exprList(o, d-1);
               o.add("L:Rbrack"); } break;
      default: name(o); break;
    }
  }

  static void mixName(List<String> o) {
    int n = 1 + rnd.nextInt(3);
    for (int i = 0; i < n; i++) o.add(pick("L:Arg", "L:ListArg", "W:+", "W:langle",
                                           "W:rangle", "L:Cross", "L:Power", "W:<",
                                           "L:Lgroup", "L:Rgroup"));
  }

  static void exprList(List<String> o, int d) {
    expr(o, d);
    while (rnd.nextInt(3) == 0) { o.add("L:Comma"); expr(o, d); }
  }

  static void nameList(List<String> o) {
    if (rnd.nextInt(6) == 0) mixName(o); else name(o);
    while (rnd.nextInt(3) == 0) { o.add("L:Comma"); name(o); }
  }

  static void decl(List<String> o, int d) {
    switch (rnd.nextInt(4)) {
      case 0: case 1: nameList(o); o.add("L:Colon"); expr(o, d); break;
      case 2: name(o); o.add("L:Defeq"); expr(o, d); break;
      default: expr(o, d); break;
    }
  }

  static void decls(List<String> o, int d) {
    decl(o, d);
    while (rnd.nextInt(3) == 0) { o.add(pick("L:Semi", "L:Linesep")); decl(o, d); }
  }

  static void props(List<String> o, int d) {
    pred(o, d);
    while (rnd.nextInt(3) == 0) { o.add(pick("L:Semi", "L:Linesep")); pred(o, d); }
  }

  static void pred(List<String> o, int d) {
    int k = d <= 0 ? rnd.nextInt(3) : rnd.nextInt(22);
    switch (k) {
      case 0: expr(o, d-1); o.add(pick("W:<", "W:=")); expr(o, d-1); break;
      case 1: o.add(pick("L:True", "L:False")); break;
      case 2: o.add("W:disjoint"); expr(o, d-1); break;
      case 3: pred(o, d-1); o.add(pick("L:And", "L:Or", "L:Implies", "L:Iff", "L:Leadsto",
              "L:Trans", "L:FollowedBy", "L:Chop")); pred(o, d-1); break;
      case 4: o.add(pick("L:Not", "L:Everywhere", "L:Somewhere", "L:Await", "L:Repeat",
              "L:Prefix")); pred(o, d-1); break;
      case 5: o.add(pick("L:Forall", "L:Exists", "L:Exists1")); decls(o, d-1);
              if (rnd.nextBoolean()) { o.add("L:Mid"); pred(o, d-1); }
              o.add("L:Spot"); pred(o, d-1); break;
      case 6: o.add("L:Lparenth"); pred(o, d-1); o.add("L:Rparenth"); break;
      case 7: expr(o, d-1); break;
      case 8: o.add("L:Lstate"); pred(o, d-1); o.add("L:Rstate"); break;
      case 9: o.add("L:Ltrans"); pred(o, d-1); o.add("L:Rtrans"); break;
      case 10: pred(o, d-1); o.add(pick("L:Duration", "L:Length")); o.add("L:Lgroup");
               name(o); o.add("L:Rgroup"); o.add("L:Lgroup"); expr(o, d-1);
               o.add("L:Rgroup"); break;
      case 11: expr(o, d-1); o.add("W:<"); expr(o, d-1); o.add("W:<"); expr(o, d-1); break;
      case 12: expr(o, d-1); o.add("W:="); o.add("W:disjoint"); expr(o, d-1); break;
      case 13: o.add("L:Lparenth"); expr(o, d-1); o.add("L:Rparenth"); o.add("W:<");
               expr(o, d-1); break;
      default: expr(o, d-1); o.add(pick("W:<", "W:=")); expr(o, d-1); break;
    }
  }

  static void item(List<String> o, int d) {
    switch (rnd.nextInt(10)) {
      case 0: if (rnd.nextInt(4) == 0) o.add(pick("L:Data", "L:Port", "L:Property",
              "L:Init")); expr(o, 1); o.add("L:Defeq"); expr(o, d); break;
      case 1: name(o); if (rnd.nextBoolean()) { o.add("L:Lbrack"); nameList(o);
              o.add("L:Rbrack"); } o.add("L:Defsyn"); name(o);
              while (rnd.nextBoolean()) { o.add("L:Mid"); name(o); if (rnd.nextBoolean()) {
              o.add("L:Ldata"); expr(o, d); o.add("L:Rdata"); } } break;
      case 2: o.add("L:Lbrack"); nameList(o); if (rnd.nextBoolean()) { o.add("L:Lbrack");
              nameList(o); o.add("L:Rbrack"); } o.add("L:Rbrack"); break;
      case 3: o.add("L:Enrich"); name(o); if (rnd.nextBoolean()) { o.add("L:Lbrack");
              exprList(o, d); o.add("L:Rbrack"); } break;
      case 4: o.add(pick("L:Input", "L:Derived")); nameList(o); break;
      default: pred(o, d); break;
    }
  }

  static void stateDecls(List<String> o) {
    nameList(o); o.add("L:Colon"); o.add(pick("L:BasicState", "L:RefState", "L:Connector"));
    while (rnd.nextBoolean()) { o.add("L:Linesep"); name(o); o.add("L:Colon");
      o.add(pick("L:BasicState", "L:RefState", "L:Connector")); }
  }

  static void labelExpr(List<String> o, int d) {
    pred(o, d); if (rnd.nextBoolean()) { o.add("L:TransLabel"); pred(o, d); }
  }

  static void transitions(List<String> o, int d) {
    name(o); if (rnd.nextBoolean()) { o.add("L:When"); labelExpr(o, d); }
    o.add("L:Goto"); name(o);
    if (rnd.nextBoolean()) { o.add("L:Linesep"); transitions(o, d); }
  }

  static List<String> mutate(List<String> o) {
    int n = rnd.nextInt(4);
    for (int i = 0; i < n; i++) {
      int op = rnd.nextInt(4);
      int p = o.isEmpty() ? 0 : rnd.nextInt(o.size() + (op == 1 ? 1 : 0));
      switch (op) {
        case 0: if (!o.isEmpty() && p < o.size()) o.remove(p); break;
        case 1: o.add(Math.min(p, o.size()), pick(ALPHABET)); break;
        case 2: if (p < o.size()) o.set(p, pick(ALPHABET)); break;
        default: if (p + 1 < o.size()) { String t = o.get(p); o.set(p, o.get(p+1));
                 o.set(p+1, t); } break;
      }
    }
    return o;
  }

  static String join(List<String> o) { return String.join(" ", o); }

  static String gen(int mode, boolean mut) {
    int d = 1 + rnd.nextInt(4);
    List<String> o = new ArrayList<>();
    switch (mode) {
      case 0: expr(o, d); if (mut) mutate(o); return "EXPR\u0001" + join(o);
      case 1: pred(o, d); if (mut) mutate(o); return "PRED\u0001" + join(o);
      case 2: {
        int n = rnd.nextInt(10);
        for (int i = 0; i < n; i++) { if (i > 0) o.add(pick("L:Linesep", "L:Semi"));
          item(o, d); }
        if (mut) mutate(o);
        return "UNIT\u0001Unboxed\u0001\u0001\u0001" + join(o);
      }
      case 3: {
        List<String> h = new ArrayList<>(), dd = new ArrayList<>(), p = new ArrayList<>();
        if (rnd.nextInt(4) == 0) h.add(pick("L:Data", "L:Port", "L:Property", "L:Init"));
        name(h); if (rnd.nextBoolean()) { h.add("L:Lbrack"); nameList(h); h.add("L:Rbrack"); }
        if (rnd.nextInt(5) > 0) decls(dd, d);
        if (rnd.nextBoolean()) props(p, d);
        if (mut) { mutate(h); mutate(dd); mutate(p); }
        return "UNIT\u0001Schema\u0001" + join(h) + "\u0001" + join(dd) + "\u0001" + join(p);
      }
      case 4: {
        List<String> dd = new ArrayList<>(), p = new ArrayList<>();
        if (rnd.nextBoolean()) { dd.add("L:Lbrack"); nameList(dd); dd.add("L:Rbrack"); }
        decls(dd, d);
        if (rnd.nextBoolean()) props(p, d);
        if (mut) { mutate(dd); mutate(p); }
        return "UNIT\u0001AxiomaticDef\u0001\u0001" + join(dd) + "\u0001" + join(p);
      }
      case 5: {
        List<String> h = new ArrayList<>(), dd = new ArrayList<>(), p = new ArrayList<>();
        if (rnd.nextBoolean()) name(h);
        stateDecls(dd);
        if (rnd.nextBoolean()) transitions(p, d);
        if (mut) { mutate(h); mutate(dd); mutate(p); }
        return "UNIT\u0001" + pick("XorState", "AndState") + "\u0001" + join(h) + "\u0001"
          + join(dd) + "\u0001" + join(p);
      }
      default: {
        List<String> h = new ArrayList<>(), dd = new ArrayList<>();
        if (rnd.nextBoolean()) name(h);
        labelExpr(dd, d);
        while (rnd.nextBoolean()) { dd.add("L:Linesep"); labelExpr(dd, d); }
        if (mut) { mutate(h); mutate(dd); }
        return "UNIT\u0001Reaction\u0001" + join(h) + "\u0001" + join(dd) + "\u0001";
      }
    }
  }

  static String xtr() {
    List<String> o = new ArrayList<>();
    int n = rnd.nextInt(8);
    for (int i = 0; i < n; i++) o.add(pick("L:Enrich", "L:Linesep", "W:A", "W:B", "N:1",
      "I:M1", "I:M2", "U:L:Enrich,W:E", "U:W:x", "K:W:x", "K:L:Enrich,W:Q"));
    return "XTR\u0001" + join(o);
  }

  static String soup() {
    List<String> o = new ArrayList<>();
    int n = 1 + rnd.nextInt(12);
    for (int i = 0; i < n; i++) o.add(pick(ALPHABET));
    String[] modes = {"EXPR", "PRED"};
    if (rnd.nextBoolean()) return pick(modes) + "\u0001" + join(o);
    return "UNIT\u0001" + pick("Unboxed", "Schema", "AxiomaticDef", "XorState", "Reaction")
      + "\u0001" + join(o.subList(0, n / 3)) + "\u0001" + join(o.subList(n / 3, 2 * n / 3))
      + "\u0001" + join(o.subList(2 * n / 3, n));
  }

  // ---- driver -------------------------------------------------------------------------

  static URLClassLoader loader(String path) throws Exception {
    String[] parts = path.split(":");
    URL[] urls = new URL[parts.length];
    for (int i = 0; i < parts.length; i++) urls[i] = new File(parts[i]).toURI().toURL();
    return new URLClassLoader(urls, ClassLoader.getPlatformClassLoader());
  }

  @SuppressWarnings("unchecked")
  static List<String> run(URLClassLoader l, List<String> specs) throws Exception {
    Class<?> g = Class.forName("Gen", true, l);
    Method m = g.getMethod("run", List.class);
    return (List<String>) m.invoke(null, specs);
  }

  public static void main(String[] args) throws Exception {
    long seed = Long.parseLong(args[2]);
    int n = Integer.parseInt(args[3]);
    rnd = new Random(seed);
    List<String> specs = new ArrayList<>();
    for (int i = 0; i < n; i++) {
      int r = rnd.nextInt(10);
      if (r == 0) specs.add(soup());
      else if (r == 1 && rnd.nextBoolean()) specs.add(xtr());
      else specs.add(gen(rnd.nextInt(7), r >= 5));
    }
    List<String> a = run(loader(args[0]), specs);
    List<String> b = run(loader(args[1]), specs);
    int noncrash = 0, bad = 0, errs = 0, excs = 0, ok = 0, clean = 0;
    java.util.TreeMap<String,Integer> exc = new java.util.TreeMap<>();
    for (int i = 0; i < n; i++) {
      String ai = a.get(i);
      if (ai.contains("EXC ")) { excs++; String k = specs.get(i).substring(0, 4) + " "
        + ai.substring(ai.indexOf("EXC ") + 4); exc.merge(k, 1, Integer::sum);
        if (exc.get(k) == 1) System.out.println("EXAMPLE " + k + ": "
          + specs.get(i).replace('\u0001', '|')); }
      else if (ai.contains(" ERROR ")) errs++;
      else if (ai.contains(" WARNING ")) errs++;
      else clean++;
      if (!a.get(i).equals(b.get(i))) {
        if (!a.get(i).contains("EXC ") || b.get(i).contains("EXC ")) noncrash++;
        if (bad < 5 || (!a.get(i).contains("EXC ") || b.get(i).contains("EXC "))) {
          System.out.println("MISMATCH " + i + ": " + specs.get(i).replace('\u0001', '|'));
          System.out.println("  REF : " + a.get(i));
          System.out.println("  PORT: " + b.get(i));
        }
        bad++;
      } else ok++;
    }
    System.out.println("specs=" + n + " same=" + ok + " differ=" + bad + " differNotFixedCrash=" + noncrash
                       + " errorDiag=" + errs + " clean=" + clean + " exceptions=" + excs + " " + exc);
  }
}
